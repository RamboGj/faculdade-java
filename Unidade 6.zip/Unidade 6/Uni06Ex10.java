public class Uni06Ex10 {
    public static void main(String[] args) {
        
    }
}
